# BR1-SW3 — Access Switch (VLAN 30)

```
hostname BR1-SW3
no ip domain-lookup
ip domain-name lab.local
enable secret [REDACTED]
username netadmin privilege 15 secret [REDACTED]
banner motd ^C
AUTHORIZED ACCESS ONLY. All activity is logged and monitored.
^C
!
service password-encryption
service tcp-keepalives-in
service tcp-keepalives-out
no service pad
no ip http server
no ip http secure-server
no ip source-route
!
vtp mode transparent
spanning-tree mode rapid-pvst
spanning-tree portfast bpduguard default
!
vlan 10
 name USERS_VLAN10
vlan 20
 name USERS_VLAN20
vlan 30
 name USERS_VLAN30
vlan 40
 name USERS_VLAN40
!
interface GigabitEthernet0/0
 description Host port
 switchport mode access
 switchport access vlan 30
 switchport port-security
 switchport port-security maximum 2
 switchport port-security violation shutdown
 switchport port-security mac-address sticky
 spanning-tree portfast
 spanning-tree bpduguard enable
 no cdp enable
!
interface GigabitEthernet0/1
 description Unused
 shutdown
!
interface GigabitEthernet0/2
 description Uplink to BR1-L3-SW1 Gi0/2
 switchport trunk encapsulation dot1q
 switchport mode trunk
 switchport trunk allowed vlan 10,20,30,40
 no shutdown
 no cdp enable
!
interface GigabitEthernet0/3
 description Uplink to BR1-L3-SW2 Gi0/2
 switchport trunk encapsulation dot1q
 switchport mode trunk
 switchport trunk allowed vlan 10,20,30,40
 no shutdown
 no cdp enable
!
interface GigabitEthernet1/0
 description Unused (replaced by Gi0/3 uplink to BR1-L3-SW2)
 shutdown
!
interface range GigabitEthernet0/4 - 23
 shutdown
!
ip ssh version 2
crypto key generate rsa modulus 2048
line con 0
 login local
 exec-timeout 5 0
line vty 0 4
 login local
 transport input ssh
 access-class MGMT-ACCESS in
 exec-timeout 5 0
!
ip access-list standard MGMT-ACCESS
 permit 10.0.0.0 0.255.255.255
 deny any log
!
ntp server 10.0.0.100
logging buffered 16384
end
```
